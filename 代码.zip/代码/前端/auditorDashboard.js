document.addEventListener("DOMContentLoaded", function () {
    const navLinks = document.querySelectorAll("nav a");
    const sections = document.querySelectorAll(".container section");

    let currentSection = "listCategories";
    document.getElementById(currentSection).classList.remove("hidden");
    document.getElementById(currentSection + "Nav").classList.add("active");

    navLinks.forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetSection = link.getAttribute("href").substring(1);

            document.getElementById(currentSection).classList.add("hidden");
            document.getElementById(currentSection + "Nav").classList.remove("active");

            document.getElementById(targetSection).classList.remove("hidden");
            link.classList.add("active");

            currentSection = targetSection;
        });
    });

    let categories = [];

    // 获取商品类目列表
    async function fetchCategories() {
        try {
            const response = await fetch('/api/categories');
            if (response.ok) {
                const data = await response.json();
                categories = data;
                renderCategories();
            } else {
                console.error('获取类目失败:', response.statusText);
            }
        } catch (error) {
            console.error('网络错误:', error);
        }
    }

    // 添加类目
    window.addCategory = async function () {
        const name = document.getElementById("categoryName").value.trim();
        if (!name) {
            alert("请输入类目名称");
            return;
        }

        try {
            const response = await fetch('/api/categories', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, product_count: 0 }),
            });

            if (response.ok) {
                const newCategory = await response.json();
                categories.push(newCategory);
                renderCategories();
                document.getElementById("categoryName").value = "";
            } else {
                alert('添加类目失败');
            }
        } catch (error) {
            console.error('添加类目失败:', error);
        }
    };

    // 删除类目
    window.deleteCategory = async function (index) {
        const category = categories[index];
        if (category.product_count > 0) {
            alert("只有当商品数为0时才能删除该类目");
            return;
        }

        try {
            const target = document.getElementById(`category-${category.id}`);
            target.classList.add('delete-category'); // 添加删除类

            const response = await fetch(`/api/categories/${category.id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                setTimeout(() => {
                    categories.splice(index, 1);
                    renderCategories();
                }, 500); // 0.5秒后移除
            } else {
                alert('删除类目失败');
                target.classList.remove('delete-category'); // 如果删除失败，移除删除类
            }
        } catch (error) {
            console.error('删除类目失败:', error);
            const target = document.getElementById(`category-${category.id}`);
            target.classList.remove('delete-category'); // 如果出现错误，移除删除类
        }
    };

    // 渲染商品类目列表
    function renderCategories() {
        const container = document.getElementById("categoryList");
        container.innerHTML = categories
            .map(
                (cat, idx) => `
                    <div id="category-${cat.id}">
                        ${cat.name} (${cat.product_count})
                        <button class="btn" onclick="deleteCategory(${idx})" ${cat.product_count > 0 ? "disabled" : ""}>删除</button>
                    </div>
                `
            )
            .join("");
    }

    // 页面加载时获取商品类目列表
    fetchCategories();
});