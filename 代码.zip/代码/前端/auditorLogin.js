document.addEventListener('DOMContentLoaded', function () {
    // 清除所有输入框的内容，以防止自动填充
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.value = '';
    });

    // 确保点击登录按钮时调用handleLogin函数
    document.getElementById('auditorLoginForm').addEventListener('submit', handleLogin);

    function handleLogin(event) {
        event.preventDefault();  // 阻止默认行为

        // 获取输入值并去除空格
        const nickname = document.getElementById('nickname').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const verificationCode = document.getElementById('verification-code').value.trim();

        // 检查所有字段是否已填写
        if (!nickname || !email || !password || !verificationCode) {
            alert('请填写所有字段');
            return;
        }

        // 检查邮箱格式是否正确
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            alert('请输入有效的电子邮件地址');
            return;
        }

        // 禁用登录按钮并更改文本为“登录中...”
        const loginButton = document.querySelector('.login-btn');
        loginButton.disabled = true;
        loginButton.textContent = '登录中...';

        // 发送登录请求
        fetch('/api/auditor/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nickname, email, password, verificationCode }),
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    window.location.href = '/auditorDashboard';
                } else {
                    alert(data.message || '登录失败，请检查输入信息');
                }
            })
            .catch((error) => {
                console.error('登录请求失败:', error);
                alert('登录请求失败，请稍后再试');
            })
            .finally(() => {
                // 重新启用登录按钮并恢复原始文本
                loginButton.disabled = false;
                loginButton.textContent = '登录';
            });
    }

    // 如果需要添加发送验证码的功能，可以在这里实现
    document.querySelector('.send-code-btn').addEventListener('click', function () {
        // 这里可以添加发送验证码的逻辑
        alert('验证码发送功能尚未实现');
    });
});