// 获取所有购物车列表
async function loadCarts() {
    let userInfo = localStorage.getItem('userInfo') || sessionStorage.getItem('userInfo');
    if (userInfo) {
        userInfo = JSON.parse(userInfo);
    }
    try {
        const response = await fetch(`/api/cart?userId=${userInfo.userID}&status=0`);
        const carts = await response.json();
        updateCartTable(carts.cart);
    } catch (error) {
        console.error('加载商品列表失败:', error);
    }
}

// 更新购物车列表
function updateCartTable(carts) {
    const productTableBody = document.getElementById('cartTable').getElementsByTagName('tbody')[0];
    const allMoneyText = document.getElementById('allMoney')
    productTableBody.innerHTML = ''; // 清空表格内容
    let allmoney = 0;
    carts.forEach(item => {
        const row = productTableBody.insertRow();
        row.innerHTML = `
            <td>${item.productName}</td>
            <td><img src="${item.image_path}" alt="${item.productName}" width="50"></td>
            <td>${item.price} 元</td>
            <td>${item.quantity}</td>
            <td>${item.status === 0 ? '未付款' : ''}</td>
            <td>
                <button onclick="deleteProduct(${item.id})">删除</button>
            </td>
        `;
        allmoney += item.quantity * item.price;
    });
    allMoneyText.innerHTML = allmoney
}

// 结算
async function cartSubmit() {
    let userInfo = localStorage.getItem('userInfo') || sessionStorage.getItem('userInfo');
    if (userInfo) {
        userInfo = JSON.parse(userInfo);
    }
    try {
        const response = await fetch(`/api/cartSubmit?userId=${userInfo.userID}`);
        const result = await response.json();
        if (result.success) {
            alert('结算成功');
            loadCarts(); // 重新加载购物车
        } else {
            alert(result.message || '结算失败');
        }
    } catch (error) {
        console.error('结算时出错:', error);
        alert('系统错误，请稍后重试');
    }
}

// 显示错误信息
function showError(message) {
    alert(message);  // 可替换为自定义的提示框
}

// 显示成功信息
function showSuccess(message) {
    alert(message);
}

// 初始化时加载商品类目和商品列表
window.addEventListener('load', async () => {
    await loadCarts();
});

// 添加点击事件监听器给侧边栏链接
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('#sidebar nav ul li a').forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // 阻止默认行为（即页面跳转）
            const href = this.getAttribute('href').substring(1); // 获取锚点ID，去掉前面的#
            showContentSection(href); // 切换到对应的内容区段
        });
    });
});