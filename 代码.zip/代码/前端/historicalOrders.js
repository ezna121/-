// 获取所有购物车列表
async function loadCarts() {
    let userInfo = localStorage.getItem('userInfo') || sessionStorage.getItem('userInfo');

    if (userInfo) {
        userInfo = JSON.parse(userInfo);
    }
    try {
        const response = await fetch(`/api/historcialOrder?userId=${userInfo.userID}&status=2`);
        const carts = await response.json();
        updateCartTable(carts.cart);
    } catch (error) {
        console.error('加载商品列表失败:', error);
    }
}


// 更新购物车列表
function updateCartTable(carts) {
    const productTableBody = document.getElementById('cartTable').getElementsByTagName('tbody')[0];
    const allMoneyText = document.getElementById('allMoney')
    productTableBody.innerHTML = ''; // 清空表格内容
    carts.forEach(item => {
        const row = productTableBody.insertRow();
        row.innerHTML = `
            <td>${item.orderId}</td>
            <td>${item.productName}</td>
            <td><img src="${item.image_path}" alt="${item.productName}" width="50"></td>
            <td>${item.price} 元</td>
            <td>${item.quantity}</td>
            <td>${['未付款', '已付款', '已付款已收货'][item.status || 2]}</td>
            <td>
                <button onclick="deleteProduct(${item.id})">删除</button>
            </td>
        `;
    });
}



// 显示错误信息
function showError(message) {
    alert(message);  // 可替换为自定义的提示框
}

// 显示成功信息
function showSuccess(message) {
    alert(message);
}

// 初始化时加载商品类目和商品列表
window.addEventListener('load', async () => {
    await loadCarts();
});


// 添加点击事件监听器给侧边栏链接
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('#sidebar nav ul li a').forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // 阻止默认行为（即页面跳转）
            const href = this.getAttribute('href').substring(1); // 获取锚点ID，去掉前面的#
            showContentSection(href); // 切换到对应的内容区段
        });
    });
});