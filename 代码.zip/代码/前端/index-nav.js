// 检查用户登录状态
function isUserLoggedIn() {
    return fetch('/getUserInfo', {
        method: 'GET',
        credentials: 'same-origin'  // 确保发送 cookies（会话信息）
    })
        .then(response => response.ok ? response.json() : Promise.reject('未登录'))
        .then(data => data.success ? data.user : null)
        .catch(err => {
            console.log('未登录:', err);
            return null;
        });
}

// 更新导航栏
function updateNavBar(user) {
    const loginLink = document.getElementById('login-link');
    const registerLink = document.getElementById('register-link');
    const userOptions = document.getElementById('user-options');
    const cartLink = document.getElementById('cart-link');
    const ordersLink = document.getElementById('orders-link');

    if (user) {
        // 隐藏登录、注册链接
        loginLink.style.display = 'none';
        registerLink.style.display = 'none';

        // 显示用户昵称和ID
        const userInfoSpan = document.querySelector('#user-info');
        if (!userInfoSpan) {
            const userInfo = document.createElement('span');
            userInfo.id = 'user-info';
            userInfo.textContent = `${user.nickname}（ID: ${user.userID}）`;
            userOptions.insertBefore(userInfo, loginLink);
        }

        // 添加退出登录按钮
        const logoutLink = document.querySelector('#logout-link');
        if (!logoutLink) {
            const logoutButton = document.createElement('a');
            logoutButton.id = 'logout-link';
            logoutButton.href = '#';
            logoutButton.textContent = '退出登录';
            logoutButton.addEventListener('click', logoutUser);
            userOptions.insertBefore(logoutButton, loginLink.nextSibling);
        }

        // 显示购物车和历史订单链接
        cartLink.style.display = 'inline';
        ordersLink.style.display = 'inline';
    } else {
        // 清除用户信息和退出按钮
        const userInfoSpan = document.querySelector('#user-info');
        if (userInfoSpan) {
            userOptions.removeChild(userInfoSpan);
        }
        const logoutLink = document.querySelector('#logout-link');
        if (logoutLink) {
            userOptions.removeChild(logoutLink);
        }

        // 显示登录、注册链接
        loginLink.style.display = 'inline';
        registerLink.style.display = 'inline';

        // 隐藏购物车和历史订单链接
        cartLink.style.display = 'inline'; // 保持可见但受保护
        ordersLink.style.display = 'inline'; // 保持可见但受保护
    }
}

// 退出登录
function logoutUser(event) {
    event.preventDefault(); // 防止默认行为
    fetch('/logout', {
        method: 'POST',
        credentials: 'same-origin'  // 确保发送 cookies（会话信息）
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('退出成功');
                window.location.href = '/';  // 跳转到主页或其他页面
            } else {
                alert('退出失败');
            }
        })
        .catch(err => console.log('退出失败:', err));
}

// 页面加载时初始化
function initializePage() {
    isUserLoggedIn()
        .then(user => {
            updateNavBar(user); // 根据登录状态更新导航栏
        });
}

// 保护链接，确保登录后才能访问购物车和历史订单页面
function setupProtectedLinks() {
    const cartLink = document.getElementById('cart-link');
    const ordersLink = document.getElementById('orders-link');

    const handleProtectedClick = (event) => {
        event.preventDefault(); // 先阻止默认跳转行为
        isUserLoggedIn()
            .then(user => {
                if (!user) {
                    alert('未登录，请先登录！');
                    window.location.href = 'login.html'; // 跳转到登录页面
                } else {
                    window.location.href = event.target.getAttribute('href'); // 继续跳转
                }
            });
    };

    if (cartLink) {
        cartLink.addEventListener('click', handleProtectedClick);
    }
    if (ordersLink) {
        ordersLink.addEventListener('click', handleProtectedClick);
    }
}

// 初始化页面和设置保护逻辑
document.addEventListener('DOMContentLoaded', () => {
    initializePage();
    setupProtectedLinks();
});