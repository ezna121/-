// 获取用户登录状态
function getUserStatus() {
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    return !!token; // 判断是否登录
}

// 当前页数和每页商品数
let currentPage = 1;
const productsPerPage = 10;

// 获取商品列表并渲染
async function loadProducts(page = 1) {
    try {
        const response = await fetch(`/api/products?page=${page}&limit=${productsPerPage}`);
        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || '加载商品失败');
        }

        const productContainer = document.getElementById('product-container');
        productContainer.innerHTML = ''; // 清空当前商品显示区域

        data.products.forEach(product => {
            const productElement = createProductElement(product);
            productContainer.appendChild(productElement);
        });

        // 渲染分页信息
        renderPagination(data.pagination);
    } catch (error) {
        console.error('加载商品失败:', error);
        alert('加载商品失败，请稍后重试');
    }
}

// 创建商品元素
function createProductElement(product) {
    const productBox = document.createElement('div');
    productBox.classList.add('product-box');

    const productImage = document.createElement('img');
    productImage.src = product.image_path; // 使用后端返回的字段
    productImage.alt = product.name;
    productImage.classList.add('product-image');

    const productName = document.createElement('div');
    productName.classList.add('product-name');
    productName.textContent = product.productName; // 使用后端返回的字段

    const productPrice = document.createElement('div');
    productPrice.classList.add('product-price');
    productPrice.textContent = `${product.price} 元`;

    const addToCartButton = document.createElement('button');
    addToCartButton.classList.add('add-to-cart');
    addToCartButton.textContent = '添加到购物车';
    addToCartButton.addEventListener('click', () => handleAddToCart(product.productID));

    productBox.appendChild(productImage);
    productBox.appendChild(productName);
    productBox.appendChild(productPrice);
    productBox.appendChild(addToCartButton);

    return productBox;
}

// 处理分页渲染
function renderPagination(pagination) {
    const paginationContainer = document.getElementById('pagination-container');
    if (!paginationContainer) {
        const container = document.createElement('div');
        container.id = 'pagination-container';
        document.body.appendChild(container);
    }

    const { totalPages, page } = pagination;
    const paginationHTML = Array.from({ length: totalPages }, (_, i) => {
        const pageNum = i + 1;
        return `
            <button class="pagination-btn ${pageNum === page ? 'active' : ''}" 
                    onclick="loadProducts(${pageNum})">${pageNum}</button>
        `;
    }).join('');

    paginationContainer.innerHTML = paginationHTML;
}

// 处理添加到购物车
function handleAddToCart(productID) {
    if (!getUserStatus()) {
        alert('请先登录！');
        window.location.href = 'login.html'; // 重定向到登录页
        return;
    }

    addToCartAPI(productID);
}

// 调用后台API将商品加入购物车
async function addToCartAPI(productID) {
    let userInfo = localStorage.getItem('userInfo') || sessionStorage.getItem('userInfo');

    if (userInfo) {
        userInfo = JSON.parse(userInfo);
    }
    try {
        const response = await fetch('/api/cart', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: userInfo.userID, productId: productID }),
        });

        if (response.ok) {
            alert('商品已加入购物车');
        } else {
            const errorData = await response.json();
            alert(errorData.message || '添加到购物车失败');
        }
    } catch (error) {
        console.error('添加到购物车时出错:', error);
        alert('系统错误，请稍后重试');
    }
}

// 初始化加载商品
window.addEventListener('load', () => {
    loadProducts(currentPage);
});
