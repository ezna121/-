document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM fully loaded and parsed');

    const userLoginForm = document.getElementById('userLoginForm');
    const merchantLoginForm = document.getElementById('merchantLoginForm');
    const auditorLoginButton = document.getElementById('auditorLoginButton');

    // 公共的登录逻辑
    async function handleLogin(event, form, endpoint, successRedirect) {
        event.preventDefault();

        const email = form.querySelector('input[name="email"]').value.trim();
        const password = form.querySelector('input[name="password"]').value.trim();
        const loginButton = form.querySelector('button[type="submit"]');
        const errorMessageElement = form.querySelector('.error-message');

        loginButton.disabled = true;
        loginButton.textContent = '登录中...';
        errorMessageElement.textContent = '';  // 清除错误信息

        try {
            // 表单验证
            if (!email || !password) {
                throw new Error('请填写所有字段');
            }
            if (!/\S+@\S+\.\S+/.test(email)) {
                throw new Error('请输入有效的电子邮件地址');
            }

            // 发起登录请求
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            if (!response.ok) {
                const result = await response.json();
                throw new Error(result.message || '网络响应不正确');
            }

            const result = await response.json();
            if (result.success) {
                if ('/userLogin' === endpoint) {
                    sessionStorage.setItem('userInfo', JSON.stringify(result.user.userInfo));
                    sessionStorage.setItem('authToken', result.user.token);
                }
                if ('/merchantLogin' === endpoint) {
                    sessionStorage.setItem('userInfo', JSON.stringify(result.merchant.merchant));
                    sessionStorage.setItem('authToken', result.merchant.token);
                }
                window.location.href = successRedirect;  // 登录成功后重定向
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            errorMessageElement.textContent = error.message;  // 显示错误信息
            errorMessageElement.classList.add('show');  // 显示错误提示
        } finally {
            loginButton.disabled = false;
            loginButton.textContent = '登录';  // 恢复登录按钮文字

            // 只有在成功的情况下才清除错误信息
            if (!errorMessageElement.textContent) {
                errorMessageElement.classList.remove('show');
            }
        }
    }

    // 用户登录表单提交事件处理
    if (userLoginForm) {
        userLoginForm.addEventListener('submit', function (event) {
            handleLogin(event, userLoginForm, '/userLogin', 'index.html');
        });
    }

    // 商家登录表单提交事件处理
    if (merchantLoginForm) {
        merchantLoginForm.addEventListener('submit', function (event) {
            handleLogin(event, merchantLoginForm, '/merchantLogin', 'merchantDashboard.html');
        });
    }

    // 管理员登录按钮点击事件处理
    if (auditorLoginButton) {
        auditorLoginButton.addEventListener('click', function () {
            window.location.href = 'auditorLogin.html'; // 直接跳转到管理员登录页面
        });
    }
});
