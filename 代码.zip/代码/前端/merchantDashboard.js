// 缓存商品类目信息，避免重复请求
let categoriesMapCache = null;

// 解析JWT并获取商家ID
function getMerchantIdFromToken(req) {
    const token = sessionStorage.getItem('authToken');
    if (!token) {
        console.error('缺少认证令牌');
        return null;
    }

    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        const payload = JSON.parse(jsonPayload);
        return payload.merchantID; // 获取商家ID
    } catch (error) {
        console.error('解析JWT失败:', error);
        return null;
    }
}

// 检查商家是否登录
async function isMerchantLoggedIn() {
    try {
        const response = await fetch('/merchantProfile', {
            method: 'GET',
            credentials: 'same-origin' // 保持会话信息
        });
        const data = await response.json();
        return response.ok && data.success ? data.merchant.merchantID : null;
    } catch (err) {
        console.log('未登录:', err);
        return null;
    }
}

// 加载商品类目信息并缓存
async function loadCategoriesMap() {
    if (categoriesMapCache) {
        populateCategoryOptions(categoriesMapCache);
        return categoriesMapCache; // 使用缓存
    }
    try {
        const response = await fetch('/api/categories');
        const data = await response.json();
        if (response.ok && data.success) {
            categoriesMapCache = data.categories.reduce((map, category) => {
                map[category.categoriesID] = category.name;
                return map;
            }, {});
            populateCategoryOptions(categoriesMapCache);
            return categoriesMapCache;
        } else {
            console.error('加载商品类目失败:', data.message);
            return null;
        }
    } catch (error) {
        console.error('加载商品类目时出错:', error);
        return null;
    }
}

function populateCategoryOptions(categoriesMap) {
    const categorySelect = document.getElementById('productCategory');
    categorySelect.innerHTML = ''; // 清空现有选项
    for (const [id, name] of Object.entries(categoriesMap)) {
        const option = document.createElement('option');
        option.value = id;
        option.textContent = name;
        categorySelect.appendChild(option);
    }
}


// 加载商品列表并更新表格
async function loadProducts() {
    const merchantId = getMerchantIdFromToken();
    if (!merchantId) {
        showError('无法获取商家ID，请重新登录！');
        return;
    }

    try {
        const response = await fetch(`/api/products?merchantId=${merchantId}`);
        const data = await response.json();
        if (response.ok && data.success) {
            const categoriesMap = await loadCategoriesMap();
            updateProductTable(data.products, categoriesMap);
        } else {
            showError('加载商品失败: ' + data.message);
        }
    } catch (error) {
        console.error('加载商品时出错:', error);
        showError('加载商品时出错');
    }
}

// 更新商品列表
function updateProductTable(products, categoriesMap) {
    const productTableBody = document.getElementById('productTable').getElementsByTagName('tbody')[0];
    productTableBody.innerHTML = ''; // 清空表格内容
    console.log('Products:', products);
    products.forEach(product => {
        const row = productTableBody.insertRow();
        row.innerHTML = `
            <td>${product.productName}</td>
            <td><img src="${product.image_path}" alt="${product.productName}" width="50"></td>
            <td>${categoriesMap[product.categoriesID]}</td>
            <td>${product.price} 元</td>
            <td>${product.stock}</td>
            <td>
                <button onclick="editProduct(${product.productID})">编辑</button>
                <button onclick="deleteProduct(${product.productID})">删除</button>
            </td>
        `;
    });
}


// 编辑商品
async function editProduct(productId) {
    try {
        const response = await fetch(`/api/products/${productId}`);
        const product = await response.json();

        if (response.ok) {
            // 填充商品信息到表单
            document.getElementById('productId').value = product.productID;
            document.getElementById('productName').value = product.productName;
            document.getElementById('productPrice').value = product.price;
            document.getElementById('productCategory').value = product.categoriesID; // 使用 categoriesID
            document.getElementById('productStock').value = product.stock;
            document.getElementById('originalImage').value = product.image_path;
            document.getElementById('imagePreview').src = product.image_path;  // 图片预览
            document.getElementById('imagePreview').style.display = 'block';

            // 显示编辑表单
            showContentSection('addProduct');
        } else {
            showError('获取商品信息失败');
        }
    } catch (error) {
        console.error('编辑商品时出错:', error);
        showError('编辑商品时出错');
    }
}

// 删除商品
async function deleteProduct(productId) {
    const confirmDelete = confirm('确定要删除该商品吗？');
    if (!confirmDelete) return;

    try {
        const response = await fetch(`/api/products/${productId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showSuccess('商品已删除');
            await loadProducts();
        } else {
            const errorText = await response.text();
            showError(`删除商品失败: ${errorText}`);
        }
    } catch (error) {
        console.error('删除商品时出错:', error);
        showError('删除商品时出错');
    }
}

// 添加或更新商品
document.getElementById('addProductForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const formData = new FormData(this);
    const productId = document.getElementById('productId').value;
    const url = productId ? `/api/products/${productId}` : '/api/products';
    const method = productId ? 'PUT' : 'POST';
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            showSuccess('商品添加成功');
            await loadProducts(); // 重新加载商品列表
            this.reset(); // 重置表单
            document.getElementById('imagePreview').style.display = 'none'; // 隐藏图片预览
        } else {
            showError(result.message || '商品添加失败');
        }
    } catch (error) {
        console.error('商品添加时出错:', error);
        showError('商品添加时出错');
    }
});

// 显示错误信息
function showError(message) {
    alert('添加失敗');  // 失敗提示框
}

// 显示成功信息
function showSuccess(message) {
    alert('添加成功');  // 成功提示框
}

// 加载商家订单并更新表格
async function loadMerchantOrders() {
    const merchantId = getMerchantIdFromToken();
    if (!merchantId) {
        showError('无法获取商家ID，请重新登录！');
        return;
    }

    try {
        const response = await fetch(`/api/merchantOrders?merchantId=${merchantId}`);
        const result = await response.json();
        if (result.success) {
            updateOrderTable(result.orders);
        } else {
            showError('加载订单失败: ' + result.message);
        }
    } catch (error) {
        console.error('加载订单时出错:', error);
        showError('加载订单时出错');
    }
}

// 更新订单表格
function updateOrderTable(orders) {
    const orderTableBody = document.getElementById('orderTable').getElementsByTagName('tbody')[0];
    orderTableBody.innerHTML = ''; // 清空表格内容

    orders.forEach(order => {
        const row = orderTableBody.insertRow();
        row.innerHTML = `
            <td>${order.productName}</td>
            <td><img src="${order.image_path}" alt="${order.productName}" width="50"></td>
            <td>${order.nickname}</td>
            <td>${order.orderId}</td>
            <td>${order.quantity}</td> <!-- 显示订单数量 -->
            <td>
                <button onclick="confirmShipment(${order.id})">确认发货</button>
            </td>
        `;
    });
}

// 确认发货
async function confirmShipment(orderId) {
    let userInfo = localStorage.getItem('userInfo') || sessionStorage.getItem('userInfo');
    if (userInfo) {
        userInfo = JSON.parse(userInfo);
    }
    try {
        const response = await fetch(`/api/merchantOrders/${orderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 2, email: userInfo.email }) // 更新状态为已收货
        });

        if (response.ok) {
            showSuccess('订单已确认发货');
            await loadMerchantOrders(); // 重新加载订单
        } else {
            const errorText = await response.text();
            showError(`确认发货失败: ${errorText}`);
        }
    } catch (error) {
        console.error('确认发货时出错:', error);
        showError('确认发货时出错');
    }
}


// 初始化时加载商品类目和商品列表
window.addEventListener('load', async () => {
    await loadCategoriesMap();
    await loadProducts();
    await loadMerchantOrders(); // 加载商家订单
    showContentSection('addProduct'); // 默认显示“商品添加”栏目

    document.getElementById('logoutBtn').addEventListener('click', async function (event) {
        event.preventDefault();
        sessionStorage.removeItem('authToken');
        const response = await fetch(`/merchantLogout`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({}) // 更新状态为已收货
        });
        if (response.ok) {
            window.location.href = '/';  // 跳转到主页
        }

    })
});

// 处理图片预览
document.getElementById('productImage').addEventListener('change', function (event) {
    const imagePreview = document.getElementById('imagePreview');
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function () {
            imagePreview.src = reader.result;
            imagePreview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});


// 切换显示的内容区段
function showContentSection(sectionId) {
    // 隐藏所有内容区段
    document.querySelectorAll('.content-section').forEach(section => section.classList.remove('active'));
    // 显示选定的内容区段
    document.getElementById(sectionId).classList.add('active');

    // 更新侧边栏激活状态
    document.querySelectorAll('#sidebar nav ul li a').forEach(link => link.classList.remove('active'));
    document.querySelector(`#sidebar nav ul li a[href="#${sectionId}"]`).classList.add('active');
}


// 添加点击事件监听器给侧边栏链接
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('#sidebar nav ul li a').forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // 阻止默认行为（即页面跳转）
            const href = this.getAttribute('href').substring(1); // 获取锚点ID，去掉前面的#
            showContentSection(href); // 切换到对应的内容区段
        });
    });
});