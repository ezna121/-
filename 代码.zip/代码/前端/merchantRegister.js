document.addEventListener('DOMContentLoaded', () => {
    const emailInput = document.getElementById('email');
    const nicknameInput = document.getElementById('nickname');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');
    const verificationCodeInput = document.getElementById('verification-code');
    const sendCodeButton = document.querySelector('.send-code-btn');
    const submitButton = document.querySelector('.signup-btn');

    const passwordHint = document.querySelector('.password-error');
    const passwordMismatchHint = document.querySelector('.confirm-password-error');
    const verificationCodeError = document.querySelector('.verification-code-error');

    let isCodeSent = false;

    // 发送验证码按钮点击事件
    sendCodeButton.addEventListener('click', async () => {
        const email = emailInput.value.trim();
        if (!email) {
            alert('请输入邮箱');
            return;
        }

        try {
            const response = await fetch('/sendVerificationCode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });

            const data = await response.json();
            if (data.success) {
                alert('验证码已发送，请查收邮箱！');
                isCodeSent = true;
            } else {
                alert('验证码发送失败，请重试！');
            }
        } catch (error) {
            console.error('发送验证码失败:', error);
            alert('验证码发送失败，请稍后再试！');
        }
    });

    // 监听密码字段的变化以验证格式
    passwordInput.addEventListener('input', function () {
        const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,16}$/;
        if (passwordInput.value.length > 0 && !passwordPattern.test(passwordInput.value)) {
            passwordHint.classList.add('show');
            passwordHint.textContent = '密码须包含大小写字母和数字，且长度为8-16位';
        } else {
            passwordHint.classList.remove('show');
            passwordHint.textContent = '';
        }
    });

    // 监听确认密码字段的变化以验证一致性
    confirmPasswordInput.addEventListener('input', function () {
        if (passwordInput.value !== confirmPasswordInput.value) {
            passwordMismatchHint.classList.add('show');
            passwordMismatchHint.textContent = '密码不一致！';
        } else {
            passwordMismatchHint.classList.remove('show');
            passwordMismatchHint.textContent = '';
        }
    });

    // 注册按钮点击事件
    submitButton.addEventListener('click', async (event) => {
        event.preventDefault();  // 防止表单默认提交，使用 JavaScript 控制

        const email = emailInput.value.trim();
        const nickname = nicknameInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();
        const verificationCode = verificationCodeInput.value.trim();

        // 验证验证码是否已发送
        if (!isCodeSent) {
            alert('请先发送验证码');
            return;
        }

        // 验证是否填写所有字段
        if (!email || !nickname || !password || !confirmPassword || !verificationCode) {
            alert('所有字段都是必填的');
            return;
        }

        // 验证密码是否一致
        if (password !== confirmPassword) {
            passwordMismatchHint.classList.add('show');
            alert('密码和确认密码不一致');
            return;
        }

        // 调用注册接口
        try {
            const response = await fetch('/registerMerchant', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: email, nickname: nickname, password: password, code: verificationCode })
            });

            const data = await response.json();
            if (data.success) {
                alert('商家入驻成功！');
                window.location.href = 'login.html';  // 跳转到登录页面
            } else {
                alert(data.message || '商家入驻失败');
            }
        } catch (error) {
            console.error('商家入驻失败:', error);
            alert('商家入驻失败，请稍后再试！');
        }
    });
});
