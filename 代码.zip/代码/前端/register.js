document.addEventListener('DOMContentLoaded', () => {
    const emailInput = document.getElementById('email');
    const nicknameInput = document.getElementById('nickname');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const verificationCodeInput = document.getElementById('code');
    const sendCodeButton = document.getElementById('sendCode');
    const registerButton = document.getElementById('register');
    const passwordHint = document.getElementById('passwordHint');
    const passwordMismatchHint = document.getElementById('passwordMismatchHint');

    let isCodeSent = false;

    // 发送验证码按钮点击事件
    sendCodeButton.addEventListener('click', async () => {
        const email = emailInput.value.trim();
        if (!email) {
            alert('请输入邮箱');
            return;
        }

        try {
            const response = await fetch('/sendVerificationCode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email }),
            });

            const data = await response.json();
            if (data.success) {
                alert('验证码已发送，请查收邮箱！');
                isCodeSent = true;
            } else {
                alert('验证码发送失败，请重试！');
            }
        } catch (error) {
            console.error('发送验证码失败:', error);
            alert('验证码发送失败，请稍后再试！');
        }
    });

    // 监听密码字段的变化以验证格式
    passwordInput.addEventListener('input', function () {
        // 正则表达式：至少一个大写字母、一个小写字母、一个数字，长度8-16
        const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,16}$/;
        if (passwordInput.value.length > 0 && !passwordPattern.test(passwordInput.value)) {
            passwordHint.classList.add('show');
            passwordHint.textContent = '8-16位大小写和数字组成！';
        } else {
            passwordHint.classList.remove('show');
            passwordHint.textContent = '';  // 清空提示信息
        }
    });

    // 监听确认密码字段的变化以验证一致性
    confirmPasswordInput.addEventListener('input', function () {
        if (passwordInput.value !== confirmPasswordInput.value) {
            passwordMismatchHint.classList.add('show');
            passwordMismatchHint.textContent = '密码不一致！';
        } else {
            passwordMismatchHint.classList.remove('show');
            passwordMismatchHint.textContent = '';  // 清空错误提示
        }
    });

    // 注册按钮点击事件
    registerButton.addEventListener('click', async (event) => {
        event.preventDefault();  // 防止表单默认提交，使用 JavaScript 控制

        const email = emailInput.value.trim();
        const nickname = nicknameInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();
        const verificationCode = verificationCodeInput.value.trim();

        if (!isCodeSent) {
            alert('请先发送验证码');
            return;
        }

        if (!email || !nickname || !password || !confirmPassword || !verificationCode) {
            alert('所有字段都是必填的');
            return;
        }

        if (password !== confirmPassword) {
            passwordMismatchHint.classList.add('show');
            alert('密码和确认密码不一致');
            return;
        }

        // 调用注册接口
        try {
            const response = await fetch('/registerUser', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email:email, nickname:nickname, password:password, code: verificationCode }),
            });

            const data = await response.json();
            if (data.success) {
                alert('注册成功！');
                window.location.href = 'login.html';  // 跳转到登录页面
            } else {
                alert(data.message || '注册失败');
            }
        } catch (error) {
            console.error('注册失败:', error);
            alert('注册失败，请稍后再试！');
        }
    });

    // 商家入驻按钮点击事件（跳转到商家入驻页面）
    const merchantRegisterButton = document.getElementById('merchantRegisterButton');
    merchantRegisterButton.addEventListener('click', () => {
        window.location.href = 'merchantRegister.html';  // 跳转到商家入驻页面
    });

    // 管理员登录按钮点击事件（跳转到管理员登录页面）
    const auditorLoginButton = document.getElementById('auditorLoginButton');
    auditorLoginButton.addEventListener('click', () => {
        window.location.href = 'auditorLogin.html';  // 跳转到管理员登录页面
    });
});
