const express = require('express');
const sql = require('mssql');
const nodemailer = require('nodemailer');
const cookieParser = require('cookie-parser');
const cookieSession = require('cookie-session');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs');
const app = express();
const dotenv = require('dotenv');
dotenv.config();  // 加载 .env 文件中的环境变量

// 获取环境变量
const JWT_SECRET = process.env.JWT_SECRET;
const SESSION_SECRET = process.env.SESSION_SECRET;
const MAIL_USER = process.env.MAIL_USER;
const MAIL_PASS = process.env.MAIL_PASS;

// 设置静态文件目录为 "前端" 文件夹（项目根目录下的 "前端"）
app.use(express.static('../前端'));

// 主页路由
app.get('/', (req, res) => {
    res.sendFile(__dirname + '../前端/index.html');  // 发送前端文件夹中的 index.html
});

// 数据库配置
const dbConfig = {
    server: 'localhost',
    user: 'sa',
    password: '123456',
    database: 'QT',
    port: 64240,
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};

// 创建数据库连接池
const poolPromise = new sql.ConnectionPool(dbConfig)
    .connect()
    .then(pool => {
        console.log('数据库连接池已建立');
        return pool;
    })
    .catch(err => {
        console.error('数据库连接失败:', err);
    });

// 使用中间件来解析请求体
app.use(express.json());  // 解析 JSON 格式的数据
app.use(express.urlencoded({ extended: true })); // 解析 urlencoded 格式的数据
app.use(cookieParser());

// 使用 cookie-session 中间件来存储会话
app.use(cookieSession({
    name: 'session',
    keys: [SESSION_SECRET],
    maxAge: 24 * 60 * 60 * 1000 // cookie 的过期时间为 24 小时
}));

// 创建邮件发送者
let transporter = nodemailer.createTransport({
    host: 'smtp.qq.com',
    port: 465,
    secure: true,
    auth: {
        user: MAIL_USER,
        pass: MAIL_PASS,
    }
});

// 用来存储验证码及其有效期的 Map
let verificationCodes = new Map();

// 生成6位随机验证码
function generateVerificationCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// 发送验证码邮件的函数
function sendVerificationEmail(recipientEmail, code) {
    const expiresAt = Date.now() + 5 * 60 * 1000;  // 设置验证码过期时间为5分钟
    verificationCodes.set(recipientEmail, { code, expiresAt });

    let mailOptions = {
        from: '1757421775@qq.com',
        to: recipientEmail,
        subject: '注册验证码',
        text: `您的验证码是: ${code}，有效期为5分钟。`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log('邮件发送失败：', error);
        }
        console.log('验证码邮件已发送: ' + `${recipientEmail}`);
    });
}
// 发送确认收货邮件的函数
function sendOrderEmail(recipientEmail, code) {
    verificationCodes.set(recipientEmail, { code, expiresAt });

    let mailOptions = {
        from: '1757421775@qq.com',
        to: recipientEmail,
        subject: '确认收货',
        text: ` 您下单的产品已发货，请注意查收`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log('邮件发送失败：', error);
        }
        console.log('邮件已发送: ' + `${recipientEmail}`);
    });
}

// 处理发送验证码请求
app.post('/sendVerificationCode', (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({ success: false, message: '邮箱不能为空' });
    }

    const verificationCode = generateVerificationCode();
    sendVerificationEmail(email, verificationCode);

    res.json({ success: true, message: '验证码已发送' });
});

// 商品展示接口
app.get('/api/products', async (req, res) => {
    const { page = 1, limit = 10, category } = req.query;

    const offset = (page - 1) * limit;

    try {
        const pool = await poolPromise;

        // 根据类别筛选商品，如果没有提供类别，则查询所有商品
        let query = `
            SELECT productID, productName, price, image_path, categoriesID ,stock
            FROM products 
            ${category ? 'WHERE categoriesID = @category' : ''}
            ORDER BY productID
            OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY
        `;
        const request = pool.request();
        if (category) {
            request.input('category', sql.VarChar, category);
        }
        request.input('offset', sql.Int, offset);
        request.input('limit', sql.Int, parseInt(limit, 10));

        const result = await request.query(query);

        // 获取商品总数
        const countQuery = `
            SELECT COUNT(*) AS total 
            FROM products 
            ${category ? 'WHERE categoriesID = @category' : ''}
        `;
        const countRequest = pool.request();
        if (category) {
            countRequest.input('category', sql.VarChar, category);
        }
        const countResult = await countRequest.query(countQuery);
        const total = countResult.recordset[0].total;

        // 返回商品信息和分页数据
        return res.json({
            success: true,
            products: result.recordset,
            pagination: {
                total,
                page: parseInt(page, 10),
                limit: parseInt(limit, 10),
                totalPages: Math.ceil(total / limit),
            },
        });
    } catch (err) {
        console.error('获取商品失败:', err);
        return res.status(500).json({ success: false, message: '获取商品失败' });
    }
});

// 商品详情接口
app.get('/api/cart', async (req, res) => {
    const { userId, status } = req.query;
    if (!userId) {
        return res.status(400).json({ success: false, message: '用户id不能为空' });
    }
    const statusWhere = status == 0 ? '(0)' : '(1,2)'
    const query = `
            SELECT
            c.id,
            c.userId,
            c.productId,
            c.quantity,
            c.status,
            p.productName AS productName,
            p.price AS price,
            p.image_path AS image_path
            FROM
                cart c
            JOIN 
                products p
            ON 
                c.productId = p.productID
            WHERE 
                c.userId = @userId AND c.status IN ${statusWhere};
        `;
    const pool = await poolPromise;
    const request = pool.request();
    request.input('userId', sql.Int, userId);

    const result = await request.query(query);

    if (result.recordset.length === 0) {
        return res.status(404).json({ success: false, message: '未找到购物车商品' });
    }

    return res.json({
        success: true,
        cart: result.recordset,
    });
});

// 添加购物车接口
app.post('/api/cart', async (req, res) => {
    const { userId, productId } = req.body;

    if (!userId) {
        return res.status(400).json({ success: false, message: '用户id不能为空' });
    }
    if (!productId) {
        return res.status(400).json({ success: false, message: '商品id不能为空' });
    }

    try {
        const pool = await poolPromise;

        // 先检查购物车中是否已经有该商品
        const getCart = `
            SELECT * FROM cart WHERE userId = @datauserId AND productId = @dataproductId;
        `;
        const request2 = pool.request();
        request2.input('datauserId', sql.Int, userId);
        request2.input('dataproductId', sql.Int, productId);
        const result = await request2.query(getCart);

        if (result.recordset.length > 0) {
            // 如果购物车中已经有该商品，更新商品数量
            const updateCart = `
                UPDATE cart
                SET quantity = quantity + 1
                WHERE userId = @datauserId AND productId = @dataproductId;
            `;
            const request3 = pool.request();
            request3.input('datauserId', sql.Int, userId);
            request3.input('dataproductId', sql.Int, productId);
            await request3.query(updateCart);
            return res.json({ success: true, message: '商品数量增加成功' });
        } else {
            // 如果购物车中没有该商品，插入新商品
            const insertCart = `
                INSERT INTO cart (userId, productId, quantity)
                VALUES (@datauserId, @dataproductId, @dataquantity);
            `;
            const request = pool.request();
            request.input('datauserId', sql.Int, userId);
            request.input('dataproductId', sql.Int, productId);
            request.input('dataquantity', sql.Int, 1);  // 新商品默认数量为1
            await request.query(insertCart);
            return res.json({ success: true, message: '商品添加成功' });
        }

    } catch (err) {
        console.error('添加购物车失败:', err);
        return res.status(500).json({ success: false, message: '添加购物车失败' });
    }
});


//查询购物车列表接口
app.get('/api/cart', async (req, res) => {
    const { userId, status } = req.query;
    if (!userId) {
        return res.status(400).json({ success: false, message: '用户id不能为空' });
    }
    const statusWhere = status == 0 ? '(0)' : '(1,2)'
    const query = `
            SELECT
            c.id,
            c.userId,
            c.productId,
            c.quantity,
            c.status,
            p.productName AS productName,
            p.price AS price,
            p.image_path AS image_path
            FROM
                cart c
            JOIN 
                products p
            ON 
                c.productId = p.productID
            WHERE 
                c.userId = @userId AND c.status IN ${statusWhere};
        `;
    const pool = await poolPromise;
    const request = pool.request();
    request.input('userId', sql.Int, userId);

    const result = await request.query(query);

    if (result.recordset.length === 0) {
        return res.status(404).json({ success: false, message: '未找到购物车商品' });
    }

    return res.json({
        success: true,
        cart: result.recordset,
    });
});


//结算接口
app.get('/api/cartSubmit', async (req, res) => {
    const { userId } = req.query;
    if (!userId) {
        return res.status(400).json({ success: false, message: '用户id不能为空' });
    }
    const query = `
        SELECT
        c.id,
        c.userId,
        c.productId,
        c.quantity,
        c.status,
        p.productName AS productName,
        p.price AS price,
        p.image_path AS image_path
        FROM
            cart c
        JOIN 
            products p
        ON 
            c.productId = p.productID
        WHERE 
            c.userId = @userId AND c.status = 0;
    `;
    const pool = await poolPromise;
    const request = pool.request();
    request.input('userId', sql.Int, userId);

    const result = await request.query(query);

    if (result.recordset.length === 0) {
        return res.status(404).json({ success: false, message: '商品未找到' });
    } else {
        let allmoney = 0;
        let insertOrderSql = ''
        result.recordset.forEach((item, index) => {
            allmoney += item.quantity * item.price;
            const orderId = "DD" + Date.now();

            if (index < result.recordset.length - 1) {
                insertOrderSql += `('${orderId}',${item.userId}, ${item.productId}, ${item.quantity},1),`
            } else {
                insertOrderSql += `('${orderId}',${item.userId}, ${item.productId}, ${item.quantity},1)`
            }
        })

        const userInfo = await getUserInfo(userId);
        if (userInfo.money >= allmoney) {
            await cutUserMoney(userId, allmoney);
            const insertSql = `
             INSERT INTO historcialOrder (orderId,userId, productId, quantity,status)
                VALUES ${insertOrderSql};`;
            await request.query(insertSql);

            const query = `
                DELETE FROM cart WHERE userId = ${userId}
            `;
            await request.query(query);

        } else {
            return res.status(404).json({ success: false, message: '用户余额不足' });
        }
    }

    return res.json({
        success: true,
        cart: result.recordset,
    });
});

//根据用户id获取用户信息
async function getUserInfo(userId) {
    const pool = await poolPromise;

    const query = `
        SELECT money
        FROM userAccount 
        WHERE userID = @userID
    `;
    const request = pool.request();
    request.input('userID', sql.Int, userId);

    const result = await request.query(query);

    if (result.recordset.length === 0) {
        return null;
    }
    return result.recordset[0]
}
//扣除用户余额
async function cutUserMoney(userId, money) {
    const pool = await poolPromise;
    try {
        const query = `
                UPDATE userAccount
                SET money = money - ${money}
                WHERE userID = @datauserId 
            `;
        const request = pool.request();
        request.input('datauserId', sql.Int, userId);
        const result = await request.query(query);
        return true
    } catch {
        return false;
    }

}

//查询历史订单列表接口
app.get('/api/historcialOrder', async (req, res) => {
    const { userId, status } = req.query;
    if (!userId) {
        return res.status(400).json({ success: false, message: '用户id不能为空' });
    }
    const query = `
            SELECT
            c.id,
            c.orderId,
            c.userId,
            c.productId,
            c.quantity,
            c.status,
            p.productName AS productName,
            p.price AS price,
            p.image_path AS image_path
            FROM
                historcialOrder c
            JOIN 
                products p
            ON 
                c.productId = p.productID
            WHERE 
                c.userId = @userId AND c.status = ${status};
        `;
    const pool = await poolPromise;
    const request = pool.request();
    request.input('userId', sql.Int, userId);

    const result = await request.query(query);

    if (result.recordset.length === 0) {
        return res.status(404).json({ success: false, message: '未找到历史订单' });
    }

    return res.json({
        success: true,
        cart: result.recordset,
    });
});


// 用户注册接口
app.post('/registerUser', async (req, res) => {
    const { email, nickname, password, code } = req.body;

    if (!email || !nickname || !password || !code) {
        return res.status(400).json({ success: false, message: '缺少必要的字段' });
    }

    // 验证验证码是否有效
    const verification = verificationCodes.get(email);
    if (!verification || verification.code !== code || Date.now() > verification.expiresAt) {
        return res.status(400).json({ success: false, message: '验证码无效或已过期' });
    }

    try {
        const pool = await poolPromise;

        // 直接使用明文密码，不进行加密
        const query = `
            INSERT INTO userAccount (email, nickname, password,money)
            OUTPUT INSERTED.userID, INSERTED.nickname
            VALUES (@dataemail, @datanickname, @datapassword,10000)
        `;
        const request = pool.request();
        request.input('dataemail', sql.VarChar, email);
        request.input('datanickname', sql.VarChar, nickname);
        request.input('datapassword', sql.VarChar, password); // 明文存储密码

        // 插入用户信息并返回 userId 和 nickname
        const result = await request.query(query);
        const userId = result.recordset[0].userID;
        const userNickname = result.recordset[0].nickname;

        // 注册成功后，清除验证码
        verificationCodes.delete(email);

        return res.json({ success: true, userId, nickname: userNickname, message: '注册成功' });
    } catch (err) {
        console.error('注册失败:', err);
        return res.status(500).json({ success: false, message: '注册失败' });
    }
});


// 用户登录接口
app.post('/userLogin', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: '请提供邮箱和密码' });
    }

    try {
        const pool = await poolPromise;
        const SELECTUser = `SELECT userID, email, nickname FROM userAccount WHERE email = @dataemail AND password = @datapassword`;
        const request = pool.request();
        request.input('dataemail', sql.VarChar, email);
        request.input('datapassword', sql.VarChar, password);

        const result = await request.query(SELECTUser);

        if (result.recordset.length === 0) {
            return res.status(401).json({ success: false, message: '无效的邮箱或密码' });
        }

        // 登录成功后，创建 JWT token
        const user = result.recordset[0];
        const token = jwt.sign({
            userID: user.userID,
            email: user.email,
            nickname: user.nickname
        }, JWT_SECRET, { expiresIn: '1h' });

        // 将 token 存储到 cookie 中
        res.cookie('authToken', token, { httpOnly: true, maxAge: 3600000 }); // 1小时过期

        return res.json({
            success: true,
            message: '登录成功',
            user: {
                userInfo: user,
                token
            },  // 返回登录成功的用户信息
        });
    } catch (err) {
        console.error('用户登录失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 获取用户信息（验证 JWT）
app.get('/getUserInfo', (req, res) => {
    const token = req.cookies.authToken;
    console.log(token)
    if (!token) {
        return res.status(401).json({ success: false, message: '未登录' });
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).json({ success: false, message: '无效的登录状态' });
        }

        return res.json({ success: true, user: decoded });
    });
});

// 用户登出
app.post('/logout', (req, res) => {
    res.clearCookie('authToken');  // 清除存储的 JWT
    res.json({ success: true, message: '注销成功' });
});

// 商家注册
app.post('/registerMerchant', async (req, res) => {
    const { email, nickname, password, code } = req.body;
    console.log(email)
    console.log(nickname)
    console.log(password)
    console.log(code)
    if (!email || !nickname || !password || !code) {
        return res.status(400).json({ success: false, message: '缺少必要字段' });
    }

    // 验证验证码是否有效
    const verification = verificationCodes.get(email);
    if (!verification || verification.code !== code || Date.now() > verification.expiresAt) {
        return res.status(400).json({ success: false, message: '验证码无效或已过期' });
    }

    try {
        const pool = await poolPromise;
        const query = `
            INSERT INTO merchantAccount (email, nickname, password, status)
            VALUES (@dataemail, @nickname, @datapassword, 1)  -- 默认状态是已通过
        `;
        const request = pool.request();
        request.input('dataemail', sql.VarChar, email);
        request.input('nickname', sql.VarChar, nickname);
        request.input('datapassword', sql.VarChar, password); // 明文存储密码

        await request.query(query);

        // 注册成功后，清除验证码
        verificationCodes.delete(email);

        return res.json({ success: true, message: '商家已成功入驻，请返回登录' });
    } catch (err) {
        console.error('商家注册失败:', err);
        return res.status(500).json({ success: false, message: '商家注册失败' });
    }
});

// 商家登录
app.post('/merchantLogin', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: '请提供邮箱和密码' });
    }

    try {
        const pool = await poolPromise;
        const SELECTMerchant = `SELECT merchantID, email, nickname, status FROM merchantAccount WHERE email = @dataemail AND password = @datapassword`;
        const request = pool.request();
        request.input('dataemail', sql.VarChar, email);
        request.input('datapassword', sql.VarChar, password);

        const result = await request.query(SELECTMerchant);

        if (result.recordset.length === 0) {
            return res.status(401).json({ success: false, message: '无效的邮箱或密码' });
        }

        const merchant = result.recordset[0];

        // 如果审核未通过，拒绝登录
        if (merchant.status !== 1) {
            return res.status(403).json({ success: false, message: '商家尚未通过审核，无法登录' });
        }

        // 登录成功后，创建 JWT token
        const token = jwt.sign({
            merchantID: merchant.merchantID,
            email: merchant.email,
            companyName: merchant.nickname
        }, JWT_SECRET, { expiresIn: '1h' });

        // 将 token 存储到 cookie 中
        res.cookie('authToken', token, { httpOnly: true, maxAge: 3600000 }); // 1小时过期

        return res.json({
            success: true,
            message: '商家登录成功',
            merchant: {
                merchant: merchant,
                token: token,
            },  // 返回商家的信息
        });
    } catch (err) {
        console.error('商家登录失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 获取当前商家信息（需登录验证）
app.get('/merchantProfile', async (req, res) => {
    const token = req.cookies.authToken;

    if (!token) {
        return res.status(401).json({ success: false, message: '未登录' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);

        const pool = await poolPromise;
        const SELECTMerchant = `SELECT merchantID, email, nickname FROM merchantAccount WHERE merchantID = @dataMerchantID`;
        const request = pool.request();
        request.input('dataMerchantID', sql.Int, decoded.merchantID);

        const result = await request.query(SELECTMerchant);

        if (result.recordset.length === 0) {
            return res.status(404).json({ success: false, message: '商家信息未找到' });
        }

        const merchant = result.recordset[0];
        return res.json({ success: true, merchant });
    } catch (err) {
        console.error('获取商家信息失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 生成 JWT
function generateToken(merchantID) {
    const payload = { merchantID };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
    return token;
}
//解析JWT获取商家ID
function getMerchantIdFromToken(req) {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        console.error('缺少认证令牌');
        return null;
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
        console.error('认证令牌格式错误');
        return null;
    }

    try {
        const base64Url = token.split('.')[1];
        if (!base64Url) {
            console.error('JWT格式错误');
            return null;
        }
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        const payload = JSON.parse(jsonPayload);
        return payload.merchantID; // 获取商家ID
    } catch (error) {
        console.error('解析JWT失败:', error);
        return null;
    }
}


// 商家登出
app.post('/merchantLogout', (req, res) => {
    res.clearCookie('authToken');
    return res.json({ success: true, message: '商家已退出登录' });
});


// 商品类目接口
app.get('/api/categories', async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request().query('SELECT categoriesID, name FROM categories');
        return res.json({ success: true, categories: result.recordset });
    } catch (err) {
        console.error('获取商品类目失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 获取商家添加的商品
app.get('/api/products', async (req, res) => {
    const { merchantId } = req.query;
    if (!merchantId) {
        return res.status(400).json({ success: false, message: '商家ID不能为空' });
    }

    try {
        const pool = await poolPromise;
        const query = `
            SELECT productID, productName, price, image_path, categoriesID, stock
            FROM products
            WHERE merchant_id = @merchantId
        `;
        const request = pool.request();
        request.input('merchantId', sql.Int, merchantId);
        const result = await request.query(query);

        return res.json({ success: true, products: result.recordset });
    } catch (err) {
        console.error('获取商品失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 配置 Multer 以保存上传的图片到指定目录
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/') // 设置文件存储路径
    },
    filename: (req, file, cb) => {
        cb(
            null,
            file.fieldname +
            '-' +
            Date.now() +
            '.' +
            file.originalname.split('.').pop()
        ) // 设置文件名
    },
});
const upload = multer({ storage: storage });

// 新增商品接口
app.post('/api/products', upload.single('image'), async (req, res) => {
    const { name, price, category, stock } = req.body;
    let image_path = '';
    const merchantId = getMerchantIdFromToken(req);

    if (!merchantId) {
        return res.status(400).json({ success: false, message: '无法获取商家ID，请重新登录' });
    }

    if (!name || !price || !category || !stock) {
        return res.status(400).json({ success: false, message: '缺少必要的字段' });
    }

    if (req.file) {
        image_path = req.file.path;  // 上传文件路径
    }

    try {
        const pool = await poolPromise;

        // 插入商品数据到 `products` 表
        const query = `
            INSERT INTO products (productName, price, categoriesID, stock, image_path, merchant_id, status)
            VALUES (@name, @price, @category, @stock, @imagePath, @merchantId, 1)
        `;
        const request = pool.request();
        request.input('name', sql.VarChar, name);
        request.input('price', sql.Decimal, price);
        request.input('category', sql.Int, category);
        request.input('stock', sql.Int, stock);
        request.input('imagePath', sql.VarChar, image_path);
        request.input('merchantId', sql.Int, merchantId);  // 商家ID从JWT解析

        await request.query(query);

        // 更新 categories 表的 product_count
        const updateCategoryQuery = `
            UPDATE categories
            SET product_count = product_count + 1
            WHERE categoriesID = @category
        `;
        await request.query(updateCategoryQuery);

        return res.json({ success: true, message: '商品添加成功' });
    } catch (err) {
        console.error('添加商品失败:', err);
        return res.status(500).json({ success: false, message: '添加商品失败' });
    }
});

// 删除商品接口
app.delete('/api/products/:id', async (req, res) => {
    const productId = req.params.id;
    console.log(`收到删除商品请求，商品ID: ${productId}`);

    try {
        const pool = await poolPromise;

        // 获取商品信息，用于删除时更新类别的 product_count
        const getProductQuery = `
            SELECT categoriesID FROM products WHERE productID = @productId
        `;
        const request = pool.request();
        request.input('productId', sql.Int, productId);

        const result = await request.query(getProductQuery);
        if (result.recordset.length === 0) {
            console.log('商品未找到');
            return res.status(404).json({ success: false, message: '商品未找到' });
        }

        const categoryId = result.recordset[0].categoriesID;

        // 删除引用该商品的所有记录
        const deleteCartItemsQuery = `
            DELETE FROM cart WHERE productId = @productId
        `;
        await request.query(deleteCartItemsQuery);

        // 删除商品数据
        const deleteProductQuery = `
            DELETE FROM products WHERE productID = @productId
        `;
        await request.query(deleteProductQuery);

        // 更新 categories 表的 product_count
        const updateCategoryQuery = `
            UPDATE categories
            SET product_count = product_count - 1
            WHERE categoriesID = @categoryId
        `;
        await request.query(updateCategoryQuery);

        console.log('商品已删除');
        return res.json({ success: true, message: '商品已删除' });
    } catch (err) {
        console.error('删除商品失败:', err);
        return res.status(500).json({ success: false, message: '删除商品失败' });
    }
});

// 编辑商品接口
app.put('/api/products/:id', upload.single('image'), async (req, res) => {
    const productId = req.params.id;
    const { name, price, category, stock, imagePath } = req.body;
    let newImagePath = imagePath || '';

    try {
        const pool = await poolPromise;

        // 获取当前商品信息
        const getProductQuery = `
            SELECT categoriesID, image_path FROM products WHERE productID = @productId
        `;
        const request = pool.request();
        request.input('productId', sql.Int, productId);

        const result = await request.query(getProductQuery);
        if (result.recordset.length === 0) {
            return res.status(404).json({ success: false, message: '商品未找到' });
        }

        const currentCategoryId = result.recordset[0].categoriesID;
        const currentImagePath = result.recordset[0].image_path;

        // 如果上传了新图片，则使用新的图片路径
        if (req.file) {
            newImagePath = req.file.path;
        } else {
            newImagePath = currentImagePath;  // 保持原来的图片路径
        }

        // 更新商品信息（不允许修改类别）
        const updateProductQuery = `
            UPDATE products
            SET productName = @name, price = @price, categoriesID = @category, stock = @stock, image_path = @imagePath
            WHERE productID = @productId
        `;
        request.input('name', sql.VarChar, name);
        request.input('price', sql.Decimal, price);
        request.input('category', sql.Int, currentCategoryId); // 类目不可修改
        request.input('stock', sql.Int, stock);
        request.input('imagePath', sql.VarChar, newImagePath);

        await request.query(updateProductQuery);

        return res.json({ success: true, message: '商品更新成功' });
    } catch (err) {
        console.error('编辑商品失败:', err);
        return res.status(500).json({ success: false, message: '编辑商品失败' });
    }
});

// 访问上传后的文件的路由
app.get('/uploads/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = 'uploads/' + filename;

    fs.readFile(filePath, (err, data) => {
        if (err) {
            console.error(err);
            res.status(404).send('文件未找到');
        } else {
            res.setHeader('Content-Type', 'image/jpeg'); // 设置响应头，指定文件类型
            res.send(data);
        }
    });
});

// 获取商家订单信息
app.get('/api/merchantOrders', async (req, res) => {
    const { merchantId } = req.query;
    if (!merchantId) {
        return res.status(400).json({ success: false, message: '商家ID不能为空' });
    }

    const query = `
        SELECT
        c.id,
        c.orderId,
        c.userId,
        c.productId,
        c.quantity,
        c.status,
        p.productName,
        p.image_path,
        u.nickname
        FROM
            historcialOrder c
        JOIN 
            products p ON c.productId = p.productID
        JOIN
            userAccount u ON c.userId = u.userID
        WHERE 
            p.merchant_id = @merchantId AND c.status = 1;
    `;
    try {
        const pool = await poolPromise;
        const request = pool.request();
        request.input('merchantId', sql.Int, merchantId);

        const result = await request.query(query);

        if (result.recordset.length === 0) {
            return res.status(404).json({ success: false, message: '未找到订单' });
        }

        return res.json({
            success: true,
            orders: result.recordset,
        });
    } catch (err) {
        console.error('获取订单失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 更新订单状态为已收货
app.put('/api/merchantOrders/:orderId', async (req, res) => {
    const { orderId } = req.params;
    const { status, email } = req.body;

    if (!orderId || status === undefined) {
        return res.status(400).json({ success: false, message: '缺少必要的字段' });
    }

    const query = `
        UPDATE historcialOrder
        SET status = @status
        WHERE id = @orderId;
    `;
    try {
        const pool = await poolPromise;
        const request = pool.request();
        request.input('orderId', sql.Int, orderId);
        request.input('status', sql.Int, status);

        await request.query(query);
        sendOrderEmail(email, orderId);
        return res.json({ success: true, message: '订单状态更新成功' });
    } catch (err) {
        console.error('更新订单状态失败:', err);
        return res.status(500).json({ success: false, message: '服务器错误' });
    }
});

// 服务器监听端口
app.listen(3000, () => {
    console.log('服务器正在运行，端口 3000');
});